Please Install:
- pygame
- opencv (cv2)
- numpy
- imutils
- scikit-learn
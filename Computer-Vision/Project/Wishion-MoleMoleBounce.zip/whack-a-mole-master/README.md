# Whack A Mole

This is a simple demo of the Whack A Mole game, written in Python.

> A typical Whac-A-Mole machine consists of a large, waist-level cabinet with five holes in its top and a large, soft, black mallet. Each hole contains a single plastic mole and the machinery necessary to move it up and down. Once the game starts, the moles will begin to pop up from their holes at random.  
> The object of the game is to force the individual moles back into their holes by hitting them directly on the head with the mallet, thereby adding to the player's score. The quicker this is done the higher the final score will be.
